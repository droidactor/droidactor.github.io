if [ "${HERDR_ENV:-}" = 1 ] && [[ $OSTYPE == msys* || $OSTYPE == cygwin* ]]; then
    __herdr_osc7() {
        local s=$? p=$PWD   # 뒤의 PROMPT_COMMAND·PS1 이 보는 $? 를 지킨다
        [[ $p == //* ]] && return $s   # UNC 경로는 file URI 로 옮기지 않는다
        if [[ $p =~ ^/([a-zA-Z])(/.*)?$ ]]; then
            p="${BASH_REMATCH[1]^^}:${BASH_REMATCH[2]:-/}"   # /f/HOME → F:/HOME (fork 없이)
        else
            p=$(cygpath -m "$p")   # /usr/bin, /tmp 같은 Git 설치 폴더 쪽 경로
        fi
        printf '\e]7;file://localhost/%s\a' "${p//%/%25}"   # herdr 가 %XX 를 풀므로 % 는 인코딩
        return $s
    }
    [[ $PROMPT_COMMAND == *__herdr_osc7* ]] || PROMPT_COMMAND="__herdr_osc7${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
fi
