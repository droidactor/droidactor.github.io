# WezTerm + Herdr 설정 (2026-11-06)

Windows에서 실제 사용 중인 설정을 묶었습니다. WezTerm 배색은 Catppuccin Macchiato,
글꼴은 JetBrains Mono Light 13pt이며 Herdr는 0.9.5에서 확인했습니다.
창의 제목 표시줄 색은 Windows 테마를 따릅니다. 해상도·배율·설치된 글꼴에 따라 표시 크기는 달라집니다.

## 준비

WezTerm, Git for Windows, JetBrains Mono 글꼴, Herdr TUI를 설치합니다.
Herdr 설치 안내: https://herdr.dev/tui/docs/install/
Claude Code와 Codex는 별도로 설치·로그인해야 합니다. 이 묶음은 AI 도구를 설치하지 않습니다.

## 적용

기존 설정은 먼저 별도로 백업한 뒤 아래 파일을 적용하세요.

1. `wezterm.lua`를 `%USERPROFILE%\.wezterm.lua`로 복사합니다.
   Git Bash가 다른 위치에 설치되어 있으면 `default_prog`와 실행 메뉴의 경로를 고칩니다.
   실행 메뉴의 MSYS·Ultra Clean 항목에 있는 `F:/Home`·`F:/Tmp`는 작성자의 예시 경로입니다.
   그 항목을 사용할 때는 본인의 경로로 바꾸거나 항목을 제거하세요.
2. `herdr/config.toml`을 `%APPDATA%\herdr\config.toml`로 복사합니다.
   `[terminal].default_shell`도 자신의 Git Bash 경로와 맞춥니다.
3. `bashrc-herdr.sh`를 Git Bash의 `~/.bashrc-herdr.sh`로 복사합니다.
   `~/.bashrc`에 `source ~/.bashrc-herdr.sh` 한 줄을 추가합니다.
   Git Bash에서 폴더를 옮긴 뒤 분할해도 새 칸이 같은 폴더를 열도록 현재 경로를 전달합니다.
   로그인 셸이 `~/.bashrc`를 읽지 않는 환경이라면 `~/.bash_profile`에서 읽도록 연결해야 합니다.
4. 새 WezTerm 창을 열고 프로젝트 폴더에서 `herdr`를 실행합니다.
   Herdr 서버가 이미 실행 중이었다면 Herdr의 메뉴에서 `reload config`를 선택합니다.
   기본 셸 변경은 새로 만든 칸부터 적용됩니다.

## 사용하는 키

키는 순서대로 누릅니다. 예를 들어 `Ctrl+U → w`는 Ctrl+U를 누르고 손을 뗀 다음 w입니다.

| 동작 | 키 |
| --- | --- |
| 단축키 메뉴 | Ctrl+U → . |
| 좌우 분할 | Ctrl+U → w |
| 상하 분할 | Ctrl+U → v |
| 왼쪽·아래·위·오른쪽 이동 | Ctrl+U → h / j / k / l |
| 현재 칸 확대·복귀 | Ctrl+U → z |
| 칸 크기 조절 | Ctrl+U → 방향키 |
| Herdr에서 분리 (작업은 계속 실행) | Ctrl+U → q |

WezTerm이 로컬 Herdr를 감지하면 위 칸 조작을 Herdr의 Ctrl+B 명령으로 바꿔 보냅니다.
WezTerm의 탭·창 조작은 계속 WezTerm이 담당합니다. Herdr 안쪽 탭은 Ctrl+B → c로 만듭니다.
Herdr의 작업 공간 선택은 Ctrl+B → m이며 사이드바 표시 전환은 Ctrl+B → Shift+B입니다.
SSH 너머·WSL 내부·WezTerm mux 도메인에서는 자동 감지하지 못하므로 Ctrl+B를 직접 사용합니다.
직접 조작할 때 좌우 분할은 Ctrl+B → w, 상하 분할은 Ctrl+B → v입니다.
공식 기본 분할 키와 다르게 맞춘 설정입니다.

`herdr`를 다시 실행하면 기존 기본 세션에 붙습니다.
`herdr --session <이름>`으로 실행했다면 같은 이름으로 다시 접속하세요.
PC 재부팅·서버 종료는 실행 중인 프로세스를 멈춥니다.
`q`로 화면에서 분리하는 것과는 다릅니다.

## 포함 범위

현재 WezTerm 설정과 Herdr 설정, 현재 폴더 전달용 Bash 부분만 담았습니다.
SSH 설정, 개인 키, 토큰, 전체 셸 초기화 파일, 대화 이력은 포함하지 않습니다.
`SHA256SUMS.txt`는 포함된 설정 파일의 SHA-256입니다.
